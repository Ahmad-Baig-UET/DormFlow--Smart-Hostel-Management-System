﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using FormFlow.Model.Users;

namespace FormFlow.Model.Payments
{
    public class Payment
    {
        public User User { get; private set; }
        public double Amount { get; private set; }
        public DateTime PaymentDate { get; private set; }

        public Payment(User user, double amount)
        {
            User = user;
            Amount = amount;
            PaymentDate = DateTime.Now;
        }
    }
}
