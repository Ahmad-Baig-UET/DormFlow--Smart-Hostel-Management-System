﻿namespace FormFlow.Model
{
    public class Class1
    {

    }
}
