﻿using System;
using System.Data.SqlClient;

namespace DormFlow_Project.DL.Database
{
    public class DbConnection
    {
        private static string connectionString =
            "Data Source=.;Initial Catalog=DormFlowDB;Integrated Security=True";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }
    }
}
