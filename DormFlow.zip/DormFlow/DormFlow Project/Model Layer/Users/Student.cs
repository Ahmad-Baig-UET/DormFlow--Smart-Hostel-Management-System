﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DormFlow_Project.Model_Layer.Users
{
    public class Student : User
    {
        public string RollNo { get; private set; }
        public string Department { get; private set; }

        public Student(int id, string name, string cnic, string rollNo, string department)
            : base(id, name, cnic)
        {
            RollNo = rollNo;
            Department = department;
        }

        public override string GetRole()
        {
            return "Student";
        }
    }
}
