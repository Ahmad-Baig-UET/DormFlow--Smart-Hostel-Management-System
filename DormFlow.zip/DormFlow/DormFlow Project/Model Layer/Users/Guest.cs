﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DormFlow_Project.Model_Layer.Users
{
    public class Guest : User
    {
        public string Purpose { get; private set; }

        public Guest(int id, string name, string cnic, string purpose)
            : base(id, name, cnic)
        {
            Purpose = purpose;
        }

        public override string GetRole()
        {
            return "Guest";
        }
    }
}
