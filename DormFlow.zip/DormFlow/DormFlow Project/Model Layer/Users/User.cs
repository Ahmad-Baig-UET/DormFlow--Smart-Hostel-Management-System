﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DormFlow_Project.Model_Layer.Users
{
    public abstract class User
    {
        public int UserId { get; protected set; }
        public string Name { get; protected set; }
        public string CNIC { get; protected set; }

        protected User(int userId, string name, string cnic)
        {
            UserId = userId;
            Name = name;
            CNIC = cnic;
        }

        public abstract string GetRole();
    }
}