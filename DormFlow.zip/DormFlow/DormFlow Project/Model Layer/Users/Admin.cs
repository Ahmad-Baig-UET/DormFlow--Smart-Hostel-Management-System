﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DormFlow_Project.Model_Layer.Users
{
    public class Admin : User
    {
        public Admin(int id, string name, string cnic)
            : base(id, name, cnic)
        {
        }

        public override string GetRole()
        {
            return "Admin";
        }

        public bool VerifyUser(Student student)
        {
            return student != null;
        }

        public bool VerifyUser(Guest guest)
        {
            return guest != null;
        }
    }
}
