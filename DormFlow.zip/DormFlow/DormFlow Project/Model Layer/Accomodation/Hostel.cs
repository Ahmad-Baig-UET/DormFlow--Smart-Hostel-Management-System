﻿using DormFlow_Project.Model_Layer.Accommodation;
using System;
using System.Collections.Generic;

namespace DormFlow_Project.Model_Layer.Accommodation
{
    public class Hostel : Building
    {
        public List<Floor> Floors { get; private set; }

        public Hostel(string name) : base(name)
        {
            Floors = new List<Floor>();
        }
    }
}
