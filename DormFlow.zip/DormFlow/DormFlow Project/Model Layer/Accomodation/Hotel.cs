﻿using DormFlow_Project.Model_Layer.Accommodation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DormFlow_Project.Model_Layer.Accommodation
{
    public class Hotel : Building
    {
        public List<Floor> Floors { get; private set; }

        public Hotel(string name) : base(name)
        {
            Floors = new List<Floor>();
        }
    }
}
