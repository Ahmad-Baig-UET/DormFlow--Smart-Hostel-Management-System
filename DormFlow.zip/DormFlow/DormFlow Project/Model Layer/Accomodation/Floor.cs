﻿
using DormFlow_Project.Model_Layer.Accommodation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DormFlow_Project.Model_Layer.Accommodation
{
    public class Floor
    {
        public int FloorNumber { get; private set; }
        public List<Room> Rooms { get; private set; }

        public Floor(int floorNumber)
        {
            FloorNumber = floorNumber;
            Rooms = new List<Room>();
        }
    }
}


