﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace DormFlow_Project.Model_Layer.Visitors
{
    public class VisitorRecord
    {
        public Visitor Visitor { get; private set; }
        public DateTime VisitTime { get; private set; }
        public DateTime? CheckoutTime { get; private set; }

        public VisitorRecord(Visitor visitor)
        {
            Visitor = visitor;
            VisitTime = DateTime.Now;
        }

        public void Checkout()
        {
            CheckoutTime = DateTime.Now;
        }
    }
}
