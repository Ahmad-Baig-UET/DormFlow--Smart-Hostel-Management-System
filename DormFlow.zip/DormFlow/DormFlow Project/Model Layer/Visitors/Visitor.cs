﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DormFlow_Project.Model_Layer.Visitors
{
    public class Visitor
    {
        public string Name { get; private set; }
        public string CNIC { get; private set; }

        public Visitor(string name, string cnic)
        {
            Name = name;
            CNIC = cnic;
        }
    }
}
