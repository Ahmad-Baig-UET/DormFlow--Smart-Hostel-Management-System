﻿namespace FormFlow.BL
{
    public class Class1
    {

    }
}
