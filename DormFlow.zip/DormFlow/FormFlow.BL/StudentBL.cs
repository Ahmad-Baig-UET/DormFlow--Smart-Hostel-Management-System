﻿using System;
using System.Data;
using FormFlow.Dl.Repositories;

namespace FormFlow.BL
{
    public class StudentBL
    {
        StudentDL _studentDL = new StudentDL();

        public void RegisterStudent(string name, string cnic, string contact, int roomNo)
        {
            
            _studentDL.RegisterStudent(name, cnic, contact, roomNo);
        }
        // This is the method your UI is looking for
        public DataTable GetStudentByMobile(long mobile)
        {
            // callling the Data Layer to fetch the table
            return _studentDL.GetStudentByMobile(mobile);
        }

        // Add this while we are here for the Update buttonsq
        public void UpdateStudent(long mobile, string name, string email)
        {
            _studentDL.UpdateStudent(mobile, name, email);
        }

        public DataTable GetAllLivingStudents()
        {
            return _studentDL.GetAllLivingStudents();
        }
    }
}